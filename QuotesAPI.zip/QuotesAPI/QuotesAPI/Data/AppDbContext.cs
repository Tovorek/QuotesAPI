﻿using Microsoft.EntityFrameworkCore;
using QuotesAPI.Models;

namespace QuotesAPI.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Quote> Quotes { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Seed data
            modelBuilder.Entity<Quote>().HasData(
                new Quote
                {
                    No = 1,
                    QuoteType = "Auto",
                    Description = "This is auto insurance",
                    Sales = "John",
                    DueDate = new DateTime(2010, 1, 1),
                    Premium = 240.00M
                },
                new Quote
                {
                    No = 2,
                    QuoteType = "Auto",
                    Description = "This is auto insurance",
                    Sales = "John",
                    DueDate = new DateTime(2010, 1, 1),
                    Premium = 240.00M
                },
                new Quote
                {
                    No = 3,
                    QuoteType = "Auto",
                    Description = "This is auto insurance",
                    Sales = "Mary",
                    DueDate = new DateTime(2011, 1, 1),
                    Premium = 300.00M
                },
                new Quote
                {
                    No = 4,
                    QuoteType = "House",
                    Description = "This is house insurance",
                    Sales = "John",
                    DueDate = new DateTime(2013, 1, 1),
                    Premium = 116.00M
                }
            );
        }
    }
}